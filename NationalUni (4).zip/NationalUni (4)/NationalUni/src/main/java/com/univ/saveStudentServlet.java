package com.univ;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Servlet implementation class adminLoginServlet
 */
@WebServlet("/saveStudentServlet")
public class saveStudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public saveStudentServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");

		Student s = new Student();
		s.setId(Integer.parseInt(request.getParameter("id")));
		s.setEmail(request.getParameter("email"));
		s.setFirstName(request.getParameter("fName"));
		s.setLastName(request.getParameter("lName"));
		s.setPhone(Integer.parseInt(request.getParameter("phone")));
		s.setSex(request.getParameter("sex"));
		s.setAge(Integer.parseInt(request.getParameter("age")));
		s.setTotalFee(Float.parseFloat(request.getParameter("totalfee")));
		s.setPaid(Float.parseFloat(request.getParameter("feepaid")));
		s.setDue(Float.parseFloat(request.getParameter("due")));
		s.setDept(DbOperations.findDepartmentById(Integer.parseInt(request.getParameter("dept"))));
		
		if(s.getId()==0)
			DbOperations.createStudent(s); 
		else
			DbOperations.updateStudent(s);
		
		request.getRequestDispatcher("viewStudents.jsp").include(request, response);  
          
	}

}
