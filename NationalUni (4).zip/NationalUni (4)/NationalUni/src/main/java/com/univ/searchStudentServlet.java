package com.univ;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

/**
 * Servlet implementation class adminLoginServlet
 */
@WebServlet("/searchStudentServlet")
public class searchStudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public searchStudentServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");

		Student s = new Student();
		s.setEmail(request.getParameter("email"));
		s.setFirstName(request.getParameter("fName"));
		s.setLastName(request.getParameter("lName"));
		if(request.getParameter("phone")!=null && request.getParameter("phone").length()>0)
			s.setPhone(Integer.parseInt(request.getParameter("phone")));
		s.setSex(request.getParameter("sex"));

		String query = "select * from Univ_Student where FK_Dept_ID=" + request.getParameter("dept");

		if(s.getEmail()!=null && s.getEmail().length()>0)
			query = query + " and Stu_Email like '%" + s.getEmail() + "%'";
		
		if(s.getFirstName()!=null && s.getFirstName().length()>0)
			query = query + " and Stu_First_Name  like '%" + s.getFirstName() + "%'";
		
		if(s.getLastName()!=null && s.getLastName().length()>0)
			query = query + " and Stu_Last_Name  like '%" + s.getLastName() + "%'";
		
		if(s.getPhone()>0)
			query = query + " and Stu_Phone  like '%" + s.getPhone() + "%'";
		
		if(s.getSex()!=null && s.getSex().length()>0)
			query = query + " and Stu_Sex  = '" + s.getSex() + "'";
		
		System.out.println("Query is " + query);
		List<Student> results = UnivDao.searchStudents(query);
		System.out.println("Results size is " + results.size());
		
		request.setAttribute("criterion", s);
		request.setAttribute("results", results);
		
		request.getRequestDispatcher("searchStudents.jsp").include(request, response);  
          
	}

}
